package com.example.wesle.punhal;

import dagger.Module;
import dagger.android.AndroidInjection;
import dagger.android.AndroidInjectionModule;
import dagger.android.AndroidInjector;
import dagger.android.ContributesAndroidInjector;

@Module(includes = AndroidInjectionModule.class)
abstract class MinhaAplicacaoModule{
    @ContributesAndroidInjector
    abstract MainActivity contributeActivityInjector();
}
