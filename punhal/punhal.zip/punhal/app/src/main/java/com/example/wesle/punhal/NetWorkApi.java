package com.example.wesle.punhal;


import javax.inject.Inject;

public class NetWorkApi {

    @Inject
    NetWorkApi() {

    }
//    public boolean ValidarUsuario(String username, String password) {
//        // imagine an actual network call here
//        // for demo purpose return false in "real" life
//        if (username == null || username.length() == 0) {
//            return false;
//        } else {
//            return true;
//        }
//    }
}
