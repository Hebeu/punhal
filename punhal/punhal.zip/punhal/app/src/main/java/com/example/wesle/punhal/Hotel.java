package com.example.wesle.punhal;

import javax.inject.Inject;

public class Hotel {
    private String nome;
    private int estrelas;
    @Inject
    public Hotel() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getEstrelas() {
        return estrelas;
    }

    public void setEstrelas(int estrelas) {
        this.estrelas = estrelas;
    }
}
